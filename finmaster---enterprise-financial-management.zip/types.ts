export enum TransactionType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE',
  DEBT = 'DEBT',
  TAX = 'TAX',
  DEPRECIATION = 'DEPRECIATION'
}

export enum AccountType {
  CASH = 'CASH',
  BANK = 'BANK',
  E_WALLET = 'E_WALLET',
  CREDIT = 'CREDIT'
}

export interface Transaction {
  id: string;
  date: string;
  type: TransactionType;
  category: string;
  amount: number;
  note: string;
  account: AccountType;
  hasInvoice: boolean;
}

export interface FinancialSummary {
  totalIncome: number;
  totalExpense: number;
  netIncome: number;
  cashBalance: number;
  outstandingDebt: number;
  monthlyBurnRate: number;
  cashRunwayMonths: number;
}

export interface RiskAnalysisResult {
  riskScore: number; // 0-100, where 100 is high risk
  summary: string;
  suggestions: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}