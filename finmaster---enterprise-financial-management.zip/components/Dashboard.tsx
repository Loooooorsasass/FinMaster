import React, { useMemo } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { ArrowUpRight, ArrowDownRight, DollarSign, Activity } from 'lucide-react';
import { Transaction, TransactionType, FinancialSummary } from '../types';

interface DashboardProps {
  transactions: Transaction[];
  summary: FinancialSummary;
}

const COLORS = ['#10b981', '#ef4444', '#f59e0b', '#6366f1'];

const Dashboard: React.FC<DashboardProps> = ({ transactions, summary }) => {
  
  const chartData = useMemo(() => {
    // Aggregate by date for the area chart
    const dataMap = new Map<string, { date: string; income: number; expense: number }>();
    
    [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .forEach(t => {
      const prev = dataMap.get(t.date) || { date: t.date, income: 0, expense: 0 };
      if (t.type === TransactionType.INCOME) prev.income += t.amount;
      if (t.type === TransactionType.EXPENSE) prev.expense += t.amount;
      dataMap.set(t.date, prev);
    });

    return Array.from(dataMap.values());
  }, [transactions]);

  const expenseBreakdown = useMemo(() => {
    const categoryMap = new Map<string, number>();
    transactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .forEach(t => {
        categoryMap.set(t.category, (categoryMap.get(t.category) || 0) + t.amount);
      });
    
    return Array.from(categoryMap.entries()).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  const StatCard = ({ title, value, icon: Icon, trend, type }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <h3 className="text-2xl font-bold text-slate-900 mt-1">
          ${value.toLocaleString()}
        </h3>
        <div className={`flex items-center mt-2 text-xs font-medium ${type === 'positive' ? 'text-emerald-600' : type === 'negative' ? 'text-red-600' : 'text-slate-600'}`}>
          {trend && (type === 'positive' ? <ArrowUpRight size={14} className="mr-1" /> : <ArrowDownRight size={14} className="mr-1" />)}
          {trend}
        </div>
      </div>
      <div className={`p-3 rounded-lg ${type === 'positive' ? 'bg-emerald-50 text-emerald-600' : type === 'negative' ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
        <Icon size={24} />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Income" 
          value={summary.totalIncome} 
          icon={DollarSign} 
          trend="+12.5% from last month"
          type="positive"
        />
        <StatCard 
          title="Total Expenses" 
          value={summary.totalExpense} 
          icon={Activity} 
          trend="+4.2% from last month"
          type="negative"
        />
        <StatCard 
          title="Net Profit" 
          value={summary.netIncome} 
          icon={Activity} 
          trend={summary.netIncome > 0 ? "Profitable" : "Loss"}
          type={summary.netIncome > 0 ? "positive" : "negative"}
        />
        <StatCard 
          title="Cash Runway" 
          value={`${summary.cashRunwayMonths.toFixed(1)} Months`} 
          icon={Activity} 
          trend="Based on avg burn rate"
          type={summary.cashRunwayMonths > 6 ? "positive" : "negative"}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Cash Flow Trends</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" name="Income" />
                <Area type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorExpense)" name="Expense" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Expense Allocation</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {expenseBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36} iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;