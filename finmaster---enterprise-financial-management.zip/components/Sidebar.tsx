import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Receipt, 
  PieChart, 
  AlertTriangle, 
  Settings, 
  Wallet
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path 
      ? "bg-slate-800 text-emerald-400 border-r-4 border-emerald-400" 
      : "text-slate-400 hover:bg-slate-800 hover:text-white";
  };

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/transactions', icon: Receipt, label: 'Transactions' },
    { path: '/cashflow', icon: Wallet, label: 'Cash Flow' },
    { path: '/risk', icon: AlertTriangle, label: 'Risk Analysis' },
    { path: '/reports', icon: PieChart, label: 'Reports' },
  ];

  return (
    <div className="w-64 bg-slate-900 h-screen fixed left-0 top-0 flex flex-col shadow-xl z-50">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-slate-900 font-bold text-lg">F</div>
          FinMaster
        </h1>
        <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider">Enterprise Edition</p>
      </div>

      <nav className="flex-1 py-6 overflow-y-auto">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center gap-3 px-6 py-3 transition-all duration-200 ${isActive(item.path)}`}
              >
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button className="flex items-center gap-3 text-slate-400 hover:text-white w-full px-2 py-2 rounded hover:bg-slate-800 transition">
          <Settings size={18} />
          <span className="text-sm">Settings</span>
        </button>
        <div className="mt-4 flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white font-bold">
            AD
          </div>
          <div>
            <p className="text-sm text-white">Admin User</p>
            <p className="text-xs text-emerald-500">Online</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;