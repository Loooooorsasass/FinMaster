import React, { useState } from 'react';
import { AlertTriangle, ShieldCheck, TrendingDown, RefreshCw, BrainCircuit } from 'lucide-react';
import { Transaction, FinancialSummary, RiskAnalysisResult } from '../types';
import { analyzeFinancialRisk } from '../services/geminiService';

interface RiskAnalysisProps {
  transactions: Transaction[];
  summary: FinancialSummary;
}

const RiskAnalysis: React.FC<RiskAnalysisProps> = ({ transactions, summary }) => {
  const [analysis, setAnalysis] = useState<RiskAnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleRunAnalysis = async () => {
    setLoading(true);
    try {
      const result = await analyzeFinancialRisk(transactions, summary);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score < 30) return 'text-emerald-500';
    if (score < 70) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreBg = (score: number) => {
    if (score < 30) return 'bg-emerald-500';
    if (score < 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Financial Risk Analysis</h2>
          <p className="text-slate-500">Real-time assessment powered by Gemini AI</p>
        </div>
        <button
          onClick={handleRunAnalysis}
          disabled={loading}
          className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition disabled:opacity-50"
        >
          {loading ? <RefreshCw className="animate-spin" size={18} /> : <BrainCircuit size={18} />}
          {loading ? 'Analyzing Data...' : 'Run AI Analysis'}
        </button>
      </div>

      {!analysis ? (
        <div className="bg-white p-12 rounded-xl border border-slate-200 text-center">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
            <BrainCircuit size={40} />
          </div>
          <h3 className="text-lg font-semibold text-slate-800">AI Insights Await</h3>
          <p className="text-slate-500 max-w-md mx-auto mt-2">
            Click the button above to let our AI analyze your cash flow, expenses, and debt ratios to generate a comprehensive risk profile.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Score Card */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center">
            <h3 className="text-slate-500 font-medium mb-4">Composite Risk Score</h3>
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="transparent"
                  className="text-slate-100"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="transparent"
                  strokeDasharray={440}
                  strokeDashoffset={440 - (440 * analysis.riskScore) / 100}
                  className={`${getScoreColor(analysis.riskScore)} transition-all duration-1000 ease-out`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className={`text-4xl font-bold ${getScoreColor(analysis.riskScore)}`}>
                  {analysis.riskScore}
                </span>
                <span className="text-xs text-slate-400 uppercase font-bold">/ 100</span>
              </div>
            </div>
            <div className={`mt-4 px-4 py-1 rounded-full text-sm font-bold text-white ${getScoreBg(analysis.riskScore)}`}>
              {analysis.riskLevel} RISK
            </div>
          </div>

          {/* Summary Card */}
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <ShieldCheck className="text-emerald-500" size={20} />
              Executive Summary
            </h3>
            <p className="text-slate-600 leading-relaxed mb-6">
              {analysis.summary}
            </p>
            
            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Key Metrics Evaluated</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-slate-50 p-3 rounded border border-slate-100">
                <p className="text-xs text-slate-500">Cash Runway</p>
                <p className="font-semibold text-slate-800">{summary.cashRunwayMonths.toFixed(1)} Mo</p>
              </div>
              <div className="bg-slate-50 p-3 rounded border border-slate-100">
                <p className="text-xs text-slate-500">Burn Rate</p>
                <p className="font-semibold text-slate-800">${summary.monthlyBurnRate.toLocaleString()}</p>
              </div>
              <div className="bg-slate-50 p-3 rounded border border-slate-100">
                <p className="text-xs text-slate-500">Debt Load</p>
                <p className="font-semibold text-slate-800">${summary.outstandingDebt.toLocaleString()}</p>
              </div>
            </div>
          </div>

          {/* Suggestions Card */}
          <div className="lg:col-span-3 bg-gradient-to-r from-slate-900 to-slate-800 p-6 rounded-xl shadow-lg text-white">
             <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <TrendingDown className="text-emerald-400" size={20} />
              Strategic Recommendations
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {analysis.suggestions.map((suggestion, idx) => (
                <div key={idx} className="bg-white/10 backdrop-blur-sm p-4 rounded-lg border border-white/10">
                  <div className="text-emerald-400 font-bold text-lg mb-2">0{idx + 1}</div>
                  <p className="text-slate-200 text-sm">{suggestion}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RiskAnalysis;