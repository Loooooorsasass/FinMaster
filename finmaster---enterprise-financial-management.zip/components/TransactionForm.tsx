import React, { useState } from 'react';
import { PlusCircle, Save, X } from 'lucide-react';
import { TransactionType, AccountType, Transaction } from '../types';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../constants';

interface TransactionFormProps {
  onAdd: (t: Omit<Transaction, 'id'>) => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ onAdd }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    type: TransactionType.EXPENSE,
    category: '',
    amount: '',
    note: '',
    account: AccountType.BANK,
    hasInvoice: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      date: formData.date,
      type: formData.type,
      category: formData.category || 'General',
      amount: parseFloat(formData.amount) || 0,
      note: formData.note,
      account: formData.account,
      hasInvoice: formData.hasInvoice
    });
    setIsOpen(false);
    setFormData({ ...formData, amount: '', note: '' });
  };

  const categories = formData.type === TransactionType.INCOME ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 bg-emerald-500 text-white p-4 rounded-full shadow-xl hover:bg-emerald-600 transition-all z-40 flex items-center gap-2"
      >
        <PlusCircle size={24} />
        <span className="font-bold">New Transaction</span>
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="bg-slate-900 p-4 flex justify-between items-center">
          <h3 className="text-white font-bold text-lg">Record Transaction</h3>
          <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">Type</label>
              <select
                className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as TransactionType })}
              >
                {Object.values(TransactionType).map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">Date</label>
              <input
                type="date"
                className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">Amount</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400">$</span>
                <input
                  type="number"
                  step="0.01"
                  className="w-full border border-slate-300 rounded-lg pl-7 p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
            </div>
            <div>
               <label className="block text-xs font-bold text-slate-500 mb-1">Category</label>
               <input 
                  list="categories" 
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  placeholder="Select or type..."
               />
               <datalist id="categories">
                  {categories.map(c => <option key={c} value={c} />)}
               </datalist>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">Account</label>
            <select
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              value={formData.account}
              onChange={(e) => setFormData({ ...formData, account: e.target.value as AccountType })}
            >
              {Object.values(AccountType).map(a => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">Notes</label>
            <textarea
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-emerald-500 outline-none h-20 resize-none"
              value={formData.note}
              onChange={(e) => setFormData({ ...formData, note: e.target.value })}
              placeholder="Optional details..."
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="invoice"
              className="w-4 h-4 text-emerald-500 rounded focus:ring-emerald-500"
              checked={formData.hasInvoice}
              onChange={(e) => setFormData({ ...formData, hasInvoice: e.target.checked })}
            />
            <label htmlFor="invoice" className="text-sm text-slate-600">Invoice attached / available</label>
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors mt-2"
          >
            <Save size={18} />
            Save Transaction
          </button>
        </form>
      </div>
    </div>
  );
};

export default TransactionForm;