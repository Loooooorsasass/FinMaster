import { Transaction, TransactionType, AccountType } from './types';

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: '1',
    date: '2023-10-01',
    type: TransactionType.INCOME,
    category: 'Sales Revenue',
    amount: 15000,
    note: 'Project A Milestone 1',
    account: AccountType.BANK,
    hasInvoice: true
  },
  {
    id: '2',
    date: '2023-10-03',
    type: TransactionType.EXPENSE,
    category: 'Office Rent',
    amount: 2000,
    note: 'October Rent',
    account: AccountType.BANK,
    hasInvoice: true
  },
  {
    id: '3',
    date: '2023-10-05',
    type: TransactionType.EXPENSE,
    category: 'Marketing',
    amount: 1200,
    note: 'Facebook Ads',
    account: AccountType.CREDIT,
    hasInvoice: true
  },
  {
    id: '4',
    date: '2023-10-10',
    type: TransactionType.EXPENSE,
    category: 'Payroll',
    amount: 8000,
    note: 'September Salaries',
    account: AccountType.BANK,
    hasInvoice: false
  },
  {
    id: '5',
    date: '2023-10-12',
    type: TransactionType.DEBT,
    category: 'Loan Repayment',
    amount: 500,
    note: 'Bank Loan Installment',
    account: AccountType.BANK,
    hasInvoice: false
  },
  {
    id: '6',
    date: '2023-10-15',
    type: TransactionType.INCOME,
    category: 'Service Fee',
    amount: 4500,
    note: 'Consulting Client B',
    account: AccountType.BANK,
    hasInvoice: true
  },
  {
    id: '7',
    date: '2023-10-20',
    type: TransactionType.EXPENSE,
    category: 'Server Costs',
    amount: 150,
    note: 'AWS Bill',
    account: AccountType.CREDIT,
    hasInvoice: true
  }
];

export const EXPENSE_CATEGORIES = [
  'Marketing', 'Payroll', 'Office Rent', 'Utilities', 'Server Costs', 
  'Travel', 'Maintenance', 'Tax', 'Other'
];

export const INCOME_CATEGORIES = [
  'Sales Revenue', 'Service Fee', 'Investment', 'Refund', 'Other'
];