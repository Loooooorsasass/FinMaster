import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TransactionForm from './components/TransactionForm';
import RiskAnalysis from './components/RiskAnalysis';
import { INITIAL_TRANSACTIONS } from './constants';
import { Transaction, TransactionType, FinancialSummary } from './types';
import { FileText, Wallet } from 'lucide-react';

const App: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);

  const addTransaction = (t: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...t,
      id: Math.random().toString(36).substring(2, 9)
    };
    setTransactions([...transactions, newTransaction]);
  };

  // Calculate real-time financials
  const summary: FinancialSummary = useMemo(() => {
    let totalIncome = 0;
    let totalExpense = 0;
    let outstandingDebt = 0;

    transactions.forEach(t => {
      if (t.type === TransactionType.INCOME) totalIncome += t.amount;
      if (t.type === TransactionType.EXPENSE) totalExpense += t.amount;
      if (t.type === TransactionType.DEBT) outstandingDebt += t.amount; // Assuming incoming debt for simplicity in this view
    });

    const netIncome = totalIncome - totalExpense;
    // Mock initial balance + net income
    const cashBalance = 50000 + netIncome; 
    
    // Calculate burn rate (average monthly expense)
    // Simplified: Total Expense / unique months, defaulting to 1 if only 1 month
    const months = new Set(transactions.map(t => t.date.substring(0, 7))).size || 1;
    const monthlyBurnRate = totalExpense / months;

    const cashRunwayMonths = monthlyBurnRate > 0 ? cashBalance / monthlyBurnRate : 999;

    return {
      totalIncome,
      totalExpense,
      netIncome,
      cashBalance,
      outstandingDebt,
      monthlyBurnRate,
      cashRunwayMonths
    };
  }, [transactions]);

  return (
    <HashRouter>
      <div className="flex bg-slate-50 min-h-screen">
        <Sidebar />
        <main className="ml-64 flex-1 p-8 overflow-y-auto h-screen">
          <div className="max-w-6xl mx-auto">
            
            {/* Header Area */}
            <header className="flex justify-between items-center mb-8">
               <div>
                 <h2 className="text-2xl font-bold text-slate-800">
                   {/* Dynamic header based on route could go here, keeping simple for now */}
                   Financial Overview
                 </h2>
                 <p className="text-slate-500 text-sm">Real-time data updated just now</p>
               </div>
               <div className="flex gap-4">
                 <div className="bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
                    <span className="text-xs text-slate-500 block">Cash Balance</span>
                    <span className="font-bold text-emerald-600">${summary.cashBalance.toLocaleString()}</span>
                 </div>
               </div>
            </header>

            <Routes>
              <Route path="/" element={<Dashboard transactions={transactions} summary={summary} />} />
              <Route path="/transactions" element={
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100">
                      <tr>
                        <th className="p-4 font-medium text-slate-500">Date</th>
                        <th className="p-4 font-medium text-slate-500">Category</th>
                        <th className="p-4 font-medium text-slate-500">Note</th>
                        <th className="p-4 font-medium text-slate-500 text-right">Amount</th>
                        <th className="p-4 font-medium text-slate-500 text-center">Type</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {[...transactions].reverse().map(t => (
                        <tr key={t.id} className="hover:bg-slate-50">
                          <td className="p-4 text-slate-600">{t.date}</td>
                          <td className="p-4 font-medium text-slate-800">{t.category}</td>
                          <td className="p-4 text-slate-500">{t.note}</td>
                          <td className={`p-4 text-right font-mono font-medium ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-900'}`}>
                            {t.type === TransactionType.INCOME ? '+' : '-'}${t.amount.toLocaleString()}
                          </td>
                          <td className="p-4 text-center">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${
                              t.type === TransactionType.INCOME ? 'bg-emerald-100 text-emerald-700' : 
                              t.type === TransactionType.EXPENSE ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'
                            }`}>
                              {t.type}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              } />
              <Route path="/risk" element={<RiskAnalysis transactions={transactions} summary={summary} />} />
              <Route path="/cashflow" element={
                 <div className="text-center py-20 text-slate-400">
                   <Wallet size={48} className="mx-auto mb-4 opacity-20" />
                   <h3 className="text-lg font-medium">Detailed Cash Flow Table</h3>
                   <p>Feature available in Pro version. Use Dashboard for charts.</p>
                 </div>
              } />
              <Route path="/reports" element={
                <div className="text-center py-20 text-slate-400">
                  <FileText size={48} className="mx-auto mb-4 opacity-20" />
                  <h3 className="text-lg font-medium">Export Reports</h3>
                  <p>PDF / Excel Export module ready to connect.</p>
                </div>
              } />
            </Routes>
          </div>
        </main>
        <TransactionForm onAdd={addTransaction} />
      </div>
    </HashRouter>
  );
};

export default App;