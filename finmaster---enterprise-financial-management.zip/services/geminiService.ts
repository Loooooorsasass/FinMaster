import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, FinancialSummary, RiskAnalysisResult } from "../types";

// Initialize Gemini Client
// Note: API KEY is assumed to be available in process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeFinancialRisk = async (
  transactions: Transaction[],
  summary: FinancialSummary
): Promise<RiskAnalysisResult> => {
  
  try {
    // Prepare context for the model
    const recentTransactions = transactions.slice(0, 20); // Last 20 transactions for brevity
    const contextData = {
      summary: summary,
      recentTransactions: recentTransactions.map(t => ({
        date: t.date,
        type: t.type,
        category: t.category,
        amount: t.amount,
        account: t.account
      }))
    };

    const prompt = `
      You are a senior financial risk analyst (CFO level). Analyze the provided financial data JSON.
      
      Data: ${JSON.stringify(contextData, null, 2)}

      Task:
      1. Calculate a 'riskScore' from 0 to 100 (0 = safe, 100 = imminent bankruptcy).
      2. Determine the 'riskLevel' (LOW, MEDIUM, HIGH, CRITICAL).
      3. Provide a concise 'summary' of the financial health.
      4. List 3-5 specific, actionable 'suggestions' to improve cash flow or reduce risk.
      
      Focus on cash runway, high expenses, and debt ratios.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskScore: { type: Type.NUMBER },
            riskLevel: { type: Type.STRING, enum: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] },
            summary: { type: Type.STRING },
            suggestions: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['riskScore', 'riskLevel', 'summary', 'suggestions']
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Empty response from Gemini");
    }

    return JSON.parse(resultText) as RiskAnalysisResult;

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Fallback data if API fails or key is missing
    return {
      riskScore: 50,
      riskLevel: 'MEDIUM',
      summary: "AI Analysis unavailable. Check API connection. Based on basic logic: ensure income exceeds expenses.",
      suggestions: [
        "Review recurring subscriptions.",
        "Follow up on outstanding invoices.",
        "Create a stricter budget for next month."
      ]
    };
  }
};